const nomes = ["Gabriel", "Tetsuya", "Tadocoro"]
omes.push("Silva")
const lista = document.getElementById("lista")

for (let nome of nomes){
    lista.innerHTML += `<li>${nome}</li>`  
}